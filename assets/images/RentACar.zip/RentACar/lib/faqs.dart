


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FaqScreeen
    extends StatelessWidget{

  @override

  Widget build(BuildContext context){

    return const Scaffold(

        body: Text("Welcome to My Showroom", ));
  }
}