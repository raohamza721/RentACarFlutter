




import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RentACarRequestScreen_screen extends StatelessWidget {

  @override

  Widget build(BuildContext context)
  {
    return const Scaffold(

      body: Text(
          "Welcome to booking screen"
      ),
    );
  }
}