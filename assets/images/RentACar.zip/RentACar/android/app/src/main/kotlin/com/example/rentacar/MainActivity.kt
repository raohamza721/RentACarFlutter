package com.example.rentacar


import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}