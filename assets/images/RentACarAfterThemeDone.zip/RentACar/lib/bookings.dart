

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class booking_screen extends StatelessWidget {

  @override

  Widget build(BuildContext context)
  {
    return Scaffold(

      body: Text(
        "Welcom to booking screen"
      ),
    );
  }
}